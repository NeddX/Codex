#include "TestScript.h"

void MienScripten::Init()
{
    std::cout << "Initialized baby!\n";
}

void MienScripten::Update(const f32 deltaTime)
{
    std::cout << "sup" << std::endl;
}

void to_json(nlohmann::ordered_json& j, const MienScripten& other)
{
    j["MienScripten"]["Id"]                             = 0;
    j["MienScripten"]["Fields"]["m_MyInteger"]["Type"]  = "i32";
    j["MienScripten"]["Fields"]["m_MyInteger"]["Value"] = other.m_MyInteger;
}

void CPrint(const char* msg)
{
    printf("Msglar: %s\n", msg);
}
